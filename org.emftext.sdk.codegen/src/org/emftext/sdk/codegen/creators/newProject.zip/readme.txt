To have more content in a fresh new project, replace the 'newProject.zip' 
file in the UI plugin of this EMFText-based DSL.