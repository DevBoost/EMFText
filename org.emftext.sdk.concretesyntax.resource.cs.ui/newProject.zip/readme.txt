To change the content of the project that is created when users invoke the new 
project wizard of your DSL, replace this ZIP file according to your needs.